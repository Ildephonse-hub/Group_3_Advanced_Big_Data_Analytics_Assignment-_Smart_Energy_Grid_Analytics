
#AUCA Smart Energy Grid Analytics
#Section 8.5 - Forecast Error Analysis

#Purpose

#Analyze the frozen Random Forest predictions on the test period.

#The script examines:
#1. Overall forecasting errors.
#2. Error statistics by region.
#3. Largest individual forecasting errors.
#4. Largest percentage errors.
#5. Hours with the largest total regional errors.
#6. Worst-performing region.

#This script DOES NOT retrain the model.
#It only analyzes the already-frozen test predictions.


from pathlib import Path

import pandas as pd


# ============================================================
# 1. PROJECT PATHS
# ============================================================

# Current file:
# D:\smart_energy_grid_analytics\code\forecasting\
#
# parents[1] points to:
# D:\smart_energy_grid_analytics\code\
FORECAST_DIR = Path(__file__).resolve().parent

# Previously created by compare_forecasting_models.py
INPUT_FILE = FORECAST_DIR / "frozen_regression_test_predictions.csv"

# Output files
ERROR_FILE = FORECAST_DIR / "forecast_error_analysis.csv"
REGION_FILE = FORECAST_DIR / "forecast_error_by_region.csv"
HOUR_FILE = FORECAST_DIR / "forecast_error_by_hour.csv"
TOP_FILE = FORECAST_DIR / "forecast_largest_errors.csv"


# ============================================================
# 2. LOAD THE FROZEN RANDOM FOREST TEST PREDICTIONS
# ============================================================

print("=" * 70)
print("LOADING FROZEN RANDOM FOREST TEST PREDICTIONS")
print("=" * 70)

df = pd.read_csv(INPUT_FILE)

print(f"Rows loaded: {len(df):,}")
print(f"Columns: {list(df.columns)}")


# ============================================================
# 3. STANDARDIZE IMPORTANT COLUMNS
# ============================================================

# Convert timestamp into a proper datetime.
#
# The original timestamps contain the CAT (+02:00) offset.
# utc=False preserves the displayed local time.
df["target_time"] = pd.to_datetime(df["target_time"])


# Make sure numerical columns are actually numeric.
df["observed_energy_kwh"] = pd.to_numeric(
    df["observed_energy_kwh"]
)

df["prediction"] = pd.to_numeric(
    df["prediction"]
)


# ============================================================
# 4. CALCULATE FORECAST ERRORS
# ============================================================

# Signed error:
#
#     prediction - actual
#
# Positive:
#     model OVER-predicted.
#
# Negative:
#     model UNDER-predicted.
df["error_kwh"] = (
    df["prediction"]
    - df["observed_energy_kwh"]
)


# Absolute error:
#
#     |prediction - actual|
#
# This measures how far the prediction was from reality
# regardless of whether it was too high or too low.
df["absolute_error_kwh"] = (
    df["error_kwh"].abs()
)


# Squared error:
#
# Large errors become much larger after squaring.
# This is the quantity used when calculating RMSE.
df["squared_error"] = (
    df["error_kwh"] ** 2
)


# Absolute percentage error:
#
#     absolute error / actual × 100
#
# We must protect against division by zero.
df["absolute_percentage_error"] = 0.0

nonzero_actual = df["observed_energy_kwh"] != 0

df.loc[nonzero_actual, "absolute_percentage_error"] = (
    df.loc[nonzero_actual, "absolute_error_kwh"]
    / df.loc[nonzero_actual, "observed_energy_kwh"]
    * 100
)


# ============================================================
# 5. OVERALL ERROR ANALYSIS
# ============================================================

print()
print("=" * 70)
print("OVERALL RANDOM FOREST TEST ERROR")
print("=" * 70)

mae = df["absolute_error_kwh"].mean()

rmse = (
    df["squared_error"].mean()
) ** 0.5

mean_error = df["error_kwh"].mean()

median_absolute_error = (
    df["absolute_error_kwh"].median()
)

max_absolute_error = (
    df["absolute_error_kwh"].max()
)

mean_percentage_error = (
    df["absolute_percentage_error"].mean()
)

print(f"Test predictions: {len(df):,}")
print(f"MAE: {mae:.6f} kWh")
print(f"RMSE: {rmse:.6f} kWh")
print(f"Mean signed error: {mean_error:.6f} kWh")
print(
    f"Median absolute error: "
    f"{median_absolute_error:.6f} kWh"
)
print(
    f"Maximum absolute error: "
    f"{max_absolute_error:.6f} kWh"
)
print(
    f"Mean absolute percentage error: "
    f"{mean_percentage_error:.6f}%"
)


# ============================================================
# 6. OVER-PREDICTION VS UNDER-PREDICTION
# ============================================================

over_predictions = (
    df["error_kwh"] > 0
).sum()

under_predictions = (
    df["error_kwh"] < 0
).sum()

exact_predictions = (
    df["error_kwh"] == 0
).sum()

print()
print("Prediction direction:")
print(f"  Over-predictions : {over_predictions:,}")
print(f"  Under-predictions: {under_predictions:,}")
print(f"  Exact predictions: {exact_predictions:,}")


# ============================================================
# 7. ERROR ANALYSIS BY REGION
# ============================================================

print()
print("=" * 70)
print("ERROR ANALYSIS BY REGION")
print("=" * 70)

region_summary = (
    df.groupby("region")
    .agg(
        test_predictions=("observed_energy_kwh", "count"),
        actual_energy_kwh=(
            "observed_energy_kwh",
            "sum",
        ),
        predicted_energy_kwh=(
            "prediction",
            "sum",
        ),
        mae_kwh=(
            "absolute_error_kwh",
            "mean",
        ),
        rmse_kwh=(
            "squared_error",
            lambda x: x.mean() ** 0.5,
        ),
        mean_signed_error_kwh=(
            "error_kwh",
            "mean",
        ),
        max_absolute_error_kwh=(
            "absolute_error_kwh",
            "max",
        ),
        mean_absolute_percentage_error=(
            "absolute_percentage_error",
            "mean",
        ),
    )
    .reset_index()
)


# Sort from worst to best based on MAE.
region_summary = region_summary.sort_values(
    "mae_kwh",
    ascending=False,
)


print(region_summary.to_string(index=False))


# ============================================================
# 8. LARGEST INDIVIDUAL FORECASTING ERRORS
# ============================================================

print()
print("=" * 70)
print("10 LARGEST INDIVIDUAL FORECASTING ERRORS")
print("=" * 70)

largest_errors = (
    df.sort_values(
        "absolute_error_kwh",
        ascending=False,
    )
    .head(10)
    [
        [
            "target_time",
            "region",
            "observed_energy_kwh",
            "prediction",
            "error_kwh",
            "absolute_error_kwh",
            "absolute_percentage_error",
        ]
    ]
)

print(largest_errors.to_string(index=False))


# ============================================================
# 9. LARGEST PERCENTAGE ERRORS
# ============================================================

print()
print("=" * 70)
print("10 LARGEST PERCENTAGE ERRORS")
print("=" * 70)

largest_percentage_errors = (
    df.sort_values(
        "absolute_percentage_error",
        ascending=False,
    )
    .head(10)
    [
        [
            "target_time",
            "region",
            "observed_energy_kwh",
            "prediction",
            "absolute_error_kwh",
            "absolute_percentage_error",
        ]
    ]
)

print(
    largest_percentage_errors.to_string(
        index=False
    )
)


# ============================================================
# 10. ERROR AGGREGATION BY HOUR
# ============================================================

print()
print("=" * 70)
print("HOURS WITH THE LARGEST TOTAL FORECAST ERROR")
print("=" * 70)

hour_summary = (
    df.groupby("target_time")
    .agg(
        regions=("region", "count"),
        total_actual_energy_kwh=(
            "observed_energy_kwh",
            "sum",
        ),
        total_predicted_energy_kwh=(
            "prediction",
            "sum",
        ),
        total_absolute_error_kwh=(
            "absolute_error_kwh",
            "sum",
        ),
        mean_absolute_error_kwh=(
            "absolute_error_kwh",
            "mean",
        ),
    )
    .reset_index()
)


hour_summary = hour_summary.sort_values(
    "total_absolute_error_kwh",
    ascending=False,
)


print(
    hour_summary.head(10).to_string(
        index=False
    )
)


# ============================================================
# 11. WORST-PERFORMING REGION
# ============================================================

worst_region = region_summary.iloc[0]

print()
print("=" * 70)
print("WORST-PERFORMING REGION")
print("=" * 70)

print(f"Region: {worst_region['region']}")
print(
    f"MAE: {worst_region['mae_kwh']:.6f} kWh"
)
print(
    f"RMSE: {worst_region['rmse_kwh']:.6f} kWh"
)
print(
    f"Maximum error: "
    f"{worst_region['max_absolute_error_kwh']:.6f} kWh"
)
print(
    f"Mean percentage error: "
    f"{worst_region['mean_absolute_percentage_error']:.6f}%"
)


# ============================================================
# 12. SAVE COMPLETE ERROR DATA
# ============================================================

df.to_csv(
    ERROR_FILE,
    index=False,
)


region_summary.to_csv(
    REGION_FILE,
    index=False,
)


hour_summary.to_csv(
    HOUR_FILE,
    index=False,
)


largest_errors.to_csv(
    TOP_FILE,
    index=False,
)


# ============================================================
# 13. FINAL SUMMARY
# ============================================================

print()
print("=" * 70)
print("FILES SAVED")
print("=" * 70)

print(ERROR_FILE)
print(REGION_FILE)
print(HOUR_FILE)
print(TOP_FILE)

print()
print("Forecast error analysis completed successfully.")